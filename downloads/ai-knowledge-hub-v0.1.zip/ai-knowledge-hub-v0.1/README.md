# AI Knowledge Hub

A simple project folder that helps your AI understand your work, keep important decisions in project files, and continue without starting over.

No coding or command line is required.

## Start in five minutes

1. Make your own copy of this folder.
2. Open that copy with ChatGPT/Codex desktop or Claude Desktop using one of the paths below.
3. Paste the setup prompt.
4. Answer up to five questions at a time.
5. Review what the AI proposes before letting it update the files.
6. Ask: **“What should I work on next?”**

Stop there. If the AI can explain your project and recommend a useful next action, the setup worked.

## Choose your AI

### ChatGPT / Codex desktop

1. Install and open the ChatGPT desktop app.
2. Start a local Work or Codex task, if available for your account.
3. Choose **Open folder** and select your copy of this folder.
4. Paste the setup prompt below.

The AI must have access to the local project folder so it can inspect and update the files. Upload-only chats are outside this template's supported workflow.

### Claude desktop

1. Install and open Claude Desktop.
2. Enable a trusted filesystem extension and allow access only to your copied folder.
3. Start a conversation and paste the setup prompt below.

The AI must have access to the local project folder so it can inspect and update the files. Upload-only chats are outside this template's supported workflow.

## Copy and paste this setup prompt

```text
Read AGENTS.md and context/INDEX.md first. Do not read every file unless the index sends you there.

Help me set up this project knowledge hub.

First, inspect the existing files without editing them. Then ask only the questions required to understand:
- what this project is;
- who it serves;
- what success means;
- what we are doing now;
- what constraints and decisions already exist.

Ask no more than five short questions at a time. Use simple language and explain any unfamiliar term.

After I answer:
1. propose content for the relevant files;
2. separate confirmed facts from assumptions;
3. wait for my approval before writing;
4. update only the files that need information;
5. give me a five-sentence project summary, the three most important open items, the best next action, and the exact prompt to use next time.

Do not invent missing facts. Write [NEEDS CONFIRMATION] beside anything uncertain.
```

## What success looks like

```text
You: Set up this knowledge hub for our new webinar campaign.

AI: I understand the basic idea. I still need the audience, desired outcome,
deadline, success measure, and current status. Here are five short questions.

You: [answers]

AI: I prepared a project brief and found three open items. Nothing has been
written yet. Here are the proposed changes for your approval.

You: Approved.

AI: Setup is complete. The best next action is to confirm the webinar offer
before producing the landing page.
```

## Three prompts you will use most

### Start a new project

```text
Read the project instructions and help me set up this knowledge hub.
```

### Continue the work

```text
Read the project instructions and continue from the latest session. Tell me what you loaded and recommend the best next action before editing anything.
```

### Finish a work session

```text
Before we finish, update the current session with what was done, what was learned, what remains open, and exactly where the next session should start. Show me the proposed update first.
```

## What each part prevents

| File or folder | What it prevents |
|---|---|
| `context/project-brief.md` | Re-explaining the project |
| `context/decisions.md` | Reversing an earlier decision |
| `context/open-items.md` | Losing unfinished work |
| `sessions/current.md` | Starting the next session from zero |
| `sources/` | Treating unsupported claims as facts |
| `outputs/` | Mixing finished work with project knowledge |
| `example/` | Wondering what completed files should look like |

## One important rule

Your AI can propose updates. You decide what becomes project truth.
