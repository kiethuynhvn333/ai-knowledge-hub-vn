# Claude entry point

Read and follow `AGENTS.md`. It is the single source of project instructions.

Begin with `context/INDEX.md`. Load only the files needed for the user’s task.

