# Outputs

Put finished work here: plans, briefs, reports, presentations, drafts for review, and other deliverables.

Outputs are not automatically project truth. If an output creates a confirmed decision or changes the project, record that separately in `context/` after user approval.

