# Project instructions

## Purpose

This folder is the durable memory for one project. Help the user understand, continue, and improve the project without making them repeat established context.

## Start every task

1. Read `context/INDEX.md`.
2. Load only the files it routes you to.
3. Read the newest entry in `sessions/current.md` when resuming work.
4. State what you loaded in one short sentence.
5. Recommend the next action before editing unless the user already requested a specific change.

Do not read every file “just in case.”

## Authority order

When information conflicts, use this order:

1. The user’s latest explicit instruction
2. Confirmed information in `context/`
3. The latest session record
4. `sources/`
5. Previous material in `outputs/`

Stop and ask when two confirmed sources conflict. Do not silently choose one.

## Working rules

- Use simple language suitable for a non-technical user.
- Ask no more than five short questions at a time.
- Separate facts, decisions, assumptions, and ideas.
- Never invent missing information.
- Mark uncertain content `[NEEDS CONFIRMATION]`.
- Show proposed changes before modifying project-memory files.
- Do not treat drafts or finished outputs as project truth.
- Do not overwrite the user’s source material.
- Do not move, rename, or delete files without explicit approval.

## Where information belongs

- Project purpose, audience, goals, scope, and constraints → `context/project-brief.md`
- Approved choices and their reasoning → `context/decisions.md`
- Unfinished work, owners, blockers, and next actions → `context/open-items.md`
- Latest handoff and resume point → `sessions/current.md`
- Original proof, links, research, and raw material → `sources/`
- Finished documents and deliverables → `outputs/`

Record information once and link to it elsewhere instead of copying it.

## Finish meaningful work

Before ending a meaningful session, propose an update to `sessions/current.md` containing:

- Done
- Learned
- Decided
- Still open
- Start here next time

Only update `context/decisions.md` when the user has made or approved a decision. Only update durable project context with confirmed information.

