# Project index

This file tells the AI where to look. It should route to project knowledge without repeating it.

## Always read

- `project-brief.md`
- The newest entry in `../sessions/current.md` when continuing existing work

## Read when needed

| User need | Read |
|---|---|
| Understand the project, audience, goal, scope, or constraints | `project-brief.md` |
| Check why a choice was made | `decisions.md` |
| Choose or continue work | `open-items.md` |
| Resume the previous session | `../sessions/current.md` |
| Verify a claim or inspect original material | `../sources/README.md`, then the relevant source |
| Review or create a finished deliverable | `../outputs/README.md`, then the relevant output |

## Current status

- Setup status: Not started
- Main priority: `[NEEDS CONFIRMATION]`
- Last reviewed: `[NEEDS CONFIRMATION]`

