# Decisions

Only record choices the user has made or explicitly approved.

## Template

### D-001 — Short decision title

- Date:
- Decision:
- Why:
- Alternatives considered:
- Owner:
- Status: Active

