# Open items

Keep this list short. Every active item needs a clear next action.

## Active now

### O-001 — Complete the initial setup

- Desired outcome: The AI can explain the project and recommend a useful next action.
- Owner: Project owner
- Next action: Run the setup prompt in `README.md`.
- Blocked by: Answers to the onboarding questions
- Status: Ready

## Waiting

None.

## Later

None.

