# Project brief

## What is this project?

`[NEEDS CONFIRMATION]`

## Who is it for?

`[NEEDS CONFIRMATION]`

## What problem does it solve?

`[NEEDS CONFIRMATION]`

## What does success look like?

`[NEEDS CONFIRMATION]`

## What are we working on now?

`[NEEDS CONFIRMATION]`

## What is included?

`[NEEDS CONFIRMATION]`

## What is not included?

`[NEEDS CONFIRMATION]`

## Constraints the AI must respect

`[NEEDS CONFIRMATION]`

