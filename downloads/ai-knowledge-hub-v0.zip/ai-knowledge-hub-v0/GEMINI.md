# Gemini entry point

Read and follow `AGENTS.md`. It is the single source of project instructions.

Begin with `context/INDEX.md`. Load only the files needed for the user’s task.

If this folder was uploaded rather than opened as a live folder, say whether you can save changes back to the files. If not, provide complete replacement text for each proposed update.

