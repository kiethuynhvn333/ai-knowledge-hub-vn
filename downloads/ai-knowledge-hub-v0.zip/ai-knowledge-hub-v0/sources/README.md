# Sources

Put original material here: research, notes, links, exports, interview transcripts, and other proof.

For every source, record:

- What it is
- Where it came from
- Its date
- What project question it supports
- Any reliability or privacy concern

Do not put passwords, API keys, or information you are not allowed to share with your AI provider in this folder.

