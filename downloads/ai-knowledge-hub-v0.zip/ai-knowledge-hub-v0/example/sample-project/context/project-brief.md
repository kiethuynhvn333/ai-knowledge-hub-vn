# Project brief

## What is this project?

A four-week campaign to launch a free live webinar called “AI Research for Growth Marketers.”

## Who is it for?

Vietnamese growth marketers who use AI chat tools but do not have a repeatable research workflow.

## What problem does it solve?

Research is slow, scattered across chats, and difficult to verify or reuse.

## What does success look like?

- 300 qualified registrations
- At least 40% live attendance
- At least 20 useful replies or direct conversations with target practitioners

## What are we working on now?

Confirming the webinar promise before writing the landing page.

## What is included?

- Webinar offer and outline
- Registration landing page
- Organic distribution posts
- Reminder messages

## What is not included?

- Paid advertising
- A recorded course
- Sales automation

## Constraints the AI must respect

- Vietnamese is the primary language.
- Use simple language with English marketing terms only where useful.
- Do not claim results that have not been measured.

