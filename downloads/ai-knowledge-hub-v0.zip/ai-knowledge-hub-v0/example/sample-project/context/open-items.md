# Open items

## Active now

### O-001 — Confirm the webinar promise

- Desired outcome: One clear promise the target audience immediately understands.
- Owner: Project owner
- Next action: Interview three target marketers about their current research workflow.
- Blocked by: Nothing
- Status: Ready

### O-002 — Draft the landing page

- Desired outcome: A publishable registration page.
- Owner: Project owner
- Next action: Start after O-001 is complete.
- Blocked by: Final webinar promise
- Status: Blocked

## Waiting

None.

## Later

- Prepare reminder messages.

