# Decisions

### D-001 — Launch as a live webinar first

- Date: 2026-09-01
- Decision: Test the material as one free live webinar before building a course.
- Why: A live session produces faster audience feedback with less production work.
- Alternatives considered: Recorded course; written guide only
- Owner: Project owner
- Status: Active

