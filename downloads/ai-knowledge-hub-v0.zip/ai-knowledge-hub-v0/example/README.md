# Completed example

The `sample-project/` folder shows what the knowledge hub looks like after a short onboarding conversation.

The example is deliberately small. Users should not need to produce a complete company wiki before receiving value.

