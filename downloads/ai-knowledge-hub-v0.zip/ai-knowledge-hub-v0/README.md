# AI Knowledge Hub

A simple project folder that helps your AI understand your work, remember important decisions, and continue without starting over.

No coding or command line is required.

## Start in five minutes

1. Make your own copy of this folder.
2. Open or upload that copy with your AI tool using one of the paths below.
3. Paste the setup prompt.
4. Answer up to five questions at a time.
5. Review what the AI proposes before letting it update the files.
6. Ask: **“What should I work on next?”**

Stop there. If the AI can explain your project and recommend a useful next action, the setup worked.

## Choose your AI

### ChatGPT desktop

1. Install and open the ChatGPT desktop app.
2. Start a local Work or Codex task, if available for your account.
3. Choose **Open folder** and select your copy of this folder.
4. Paste the setup prompt below.

If local folder access is unavailable, upload the files from `context/` plus `AGENTS.md` to a chat. The AI may not be able to save changes back to your computer.

### Claude desktop

1. Install and open Claude Desktop.
2. Enable a trusted filesystem extension and allow access only to your copied folder.
3. Start a conversation and paste the setup prompt below.

If you do not want to enable local access, upload the starter files manually. The AI may not be able to save changes back to your computer.

### Gemini web

1. Open Gemini in your browser.
2. Choose **Add files → More uploads → Import code → Upload folder**.
3. Select your copy of this folder.
4. Paste the setup prompt below.

Gemini may treat the folder as uploaded chat context rather than a live folder. Test whether it can update files before relying on automatic session records.

## Copy and paste this setup prompt

```text
Read AGENTS.md and context/INDEX.md first. Do not read every file unless the index sends you there.

Help me set up this project knowledge hub.

First, inspect the existing files without editing them. Then ask only the questions required to understand:
- what this project is;
- who it serves;
- what success means;
- what we are doing now;
- what constraints and decisions already exist.

Ask no more than five short questions at a time. Use simple language and explain any unfamiliar term.

After I answer:
1. propose content for the relevant files;
2. separate confirmed facts from assumptions;
3. wait for my approval before writing;
4. update only the files that need information;
5. give me a five-sentence project summary, the three most important open items, the best next action, and the exact prompt to use next time.

Do not invent missing facts. Write [NEEDS CONFIRMATION] beside anything uncertain.
```

## What success looks like

```text
You: Set up this knowledge hub for our new webinar campaign.

AI: I understand the basic idea. I still need the audience, desired outcome,
deadline, success measure, and current status. Here are five short questions.

You: [answers]

AI: I prepared a project brief and found three open items. Nothing has been
written yet. Here are the proposed changes for your approval.

You: Approved.

AI: Setup is complete. The best next action is to confirm the webinar offer
before producing the landing page.
```

## Three prompts you will use most

### Start a new project

```text
Read the project instructions and help me set up this knowledge hub.
```

### Continue the work

```text
Read the project instructions and continue from the latest session. Tell me what you loaded and recommend the best next action before editing anything.
```

### Finish a work session

```text
Before we finish, update the current session with what was done, what was learned, what remains open, and exactly where the next session should start. Show me the proposed update first.
```

## What each part prevents

| File or folder | What it prevents |
|---|---|
| `context/project-brief.md` | Re-explaining the project |
| `context/decisions.md` | Reversing an earlier decision |
| `context/open-items.md` | Losing unfinished work |
| `sessions/current.md` | Starting the next session from zero |
| `sources/` | Treating unsupported claims as facts |
| `outputs/` | Mixing finished work with project knowledge |
| `example/` | Wondering what completed files should look like |

## One important rule

Your AI can propose updates. You decide what becomes project truth.

