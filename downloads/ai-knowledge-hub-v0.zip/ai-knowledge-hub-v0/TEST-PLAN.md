# Cross-agent onboarding test

Test the same untouched copy of the starter folder with ChatGPT, Claude, and Gemini. Use a fresh copy and a new conversation for every run.

## What we are testing

Can a non-technical person reach a useful first result without understanding the folder architecture?

## Test task

Use this fictional starting context in every run:

```text
I am preparing a free webinar for Vietnamese growth marketers about using AI for research. I want to launch it in four weeks. I have not decided the exact promise, format, or success target.
```

Then paste the setup prompt from `README.md`.

## Test procedure

1. Start a timer before opening or uploading the folder.
2. Follow only the instructions visible in `README.md`.
3. Do not help the AI find files unless it asks.
4. Answer its onboarding questions using the test task above.
5. Approve reasonable proposed changes.
6. Ask: “What should I work on next?”
7. End the session with the close-session prompt.
8. Start a new conversation and use the continue-work prompt.

## Scorecard

Score each item from 0 to 2.

| Measure | 0 | 1 | 2 |
|---|---|---|---|
| Setup clarity | Could not start | Needed help | Started without help |
| Correct entry point | Ignored instructions | Needed direction | Found and followed instructions |
| Question quality | Generic or excessive | Partly useful | Five or fewer high-value questions |
| Fact safety | Invented facts | Some ambiguity | Clearly separated unknowns |
| Proposed changes | Edited without review | Partial review | Showed changes before writing |
| First useful result | No useful result | Partial summary | Clear summary and next action |
| Resume quality | Started over | Remembered some context | Continued from exact prior state |
| File updates | Failed or damaged files | Incomplete | Correct minimal updates |

Maximum score: 16.

## Timing

Record:

- Time to begin setup
- Time to first useful project summary
- Time to recommended next action
- Time required to resume in a new conversation

Primary target: useful summary and next action within five minutes, excluding the user’s time answering questions.

## Friction log

For every hesitation or failure, record:

- What the user tried
- What they expected
- What happened
- Whether the problem came from the instructions, the folder, or the AI product
- Smallest possible fix

## Test result template

```text
Platform:
Product and version:
Date:
Access method: live folder | uploaded folder | individual files
Total score:
Time to first value:

What worked:
-

Where the user hesitated:
-

Where the AI failed:
-

Files changed correctly:
-

Highest-impact improvement:
-
```

## Pass rule

The v0 passes on a platform when:

- it scores at least 13/16;
- it produces a useful summary and next action;
- it invents no project facts;
- it can resume from the recorded state, or clearly explains that uploaded files must be supplied again.

